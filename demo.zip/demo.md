```python
import pandas as pd
import os
import numpy as np
```


```python
!dir
```

     驱动器 G 中的卷没有标签。
     卷的序列号是 10DE-CC9B
    
     G:\mission\python\July_August\商品分析 的目录
    
    2024/08/15  01:43    <DIR>          .
    2024/08/13  10:15    <DIR>          ..
    2024/08/13  10:29    <DIR>          dataset
    2024/08/15  01:43            57,163 demo.ipynb
    2024/08/14  19:51             1,565 demo.py
    2024/08/14  16:41         1,665,578 final.xlsx
    2024/08/14  23:48         3,562,902 llm_out.ipynb
    2024/08/14  19:51    <DIR>          logs
    2024/08/14  23:44       112,250,515 results.json
    2024/08/15  01:26        36,138,578 vllm.ipynb
                   6 个文件    153,676,301 字节
                   4 个目录 178,571,821,056 可用字节
    


```python
jingdong_path = "./dataset/京东评论/"
jingdong_list = os.listdir(jingdong_path)
jingdong_files = [jingdong_path + find_file for find_file in jingdong_list]
print(jingdong_list)
data_jingdong_dfs = [pd.read_excel(path) for path in jingdong_files]
```

    ['京东商品评论卫生巾（苏菲，abc，七度空间，护舒宝）.xlsx', '京东商品评论卫生棉条ob.xlsx', '京东商品评论卫生棉条丹碧丝.xlsx', '京东商品评论卫生棉条苏菲.xlsx', '京东商品评论安心裤ABC.xlsx', '京东商品评论安心裤七度空间.xlsx', '京东商品评论安心裤护舒宝.xlsx', '京东商品评论安心裤苏菲.xlsx', '京东商品评论液体卫生巾护舒宝.xlsx']
    


```python
def f(text):
    text = str(text).lower()
    keywords = {
        '苏菲': '苏菲',
        'abc': 'ABC',
        '七度空间': '七度空间',
        '丹碧丝': '丹碧丝',
        'ob': 'ob',
        '护舒宝': '护舒宝',
        '安尔乐': '安尔乐',
    }

    for key, value in keywords.items():
        if key in text:
            return value

    return '其他'
```


```python
def category(text):
    text = str(text).lower()
    keywords = {
        '液体卫生巾': '液体卫生巾',
        '卫生棉条': '卫生棉条',
        '安心裤': '安心裤',
        '卫生巾': '卫生巾'
    }

    for key, value in keywords.items():
        if key in text:
            return value

    return '其他'

```


```python
for i, df in enumerate(data_jingdong_dfs):
	df['来源平台'] = ['京东' for _ in range(len(df))]
	df['品牌名称'] = df['页面标题'].apply(f)
	df['品牌大类'] = df['页面标题'].apply(category)
	df['评论字数'] = df['评价内容'].apply(len)

	print(set(df['品牌名称'].tolist()))
	print(set(df['品牌大类'].tolist()))
	print("=" * 100)
```

    {'苏菲', 'ABC', '七度空间', '护舒宝'}
    {'卫生巾'}
    ====================================================================================================
    {'ob'}
    {'卫生棉条'}
    ====================================================================================================
    {'丹碧丝'}
    {'卫生棉条'}
    ====================================================================================================
    {'苏菲'}
    {'卫生棉条'}
    ====================================================================================================
    {'ABC'}
    {'卫生巾'}
    ====================================================================================================
    {'七度空间'}
    {'安心裤'}
    ====================================================================================================
    {'护舒宝'}
    {'安心裤'}
    ====================================================================================================
    {'苏菲'}
    {'安心裤'}
    ====================================================================================================
    {'护舒宝'}
    {'液体卫生巾'}
    ====================================================================================================
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['KaiTi', 'SimHei', 'FangSong']  # Chinese font preference: KaiTi, SimHei, FangSong
plt.rcParams['font.size'] = 12  # Font size
plt.rcParams['axes.unicode_minus'] = False  # Display minus sign correctly for Chinese characters
```


```python
def data_analysis(df):
    # Display the situation of data fields, such as data type, unique values, and the proportion of missing data.
    output = pd.DataFrame(columns = ["Column", "Data Type", "Unique values", "NaN"])

    for column in df.columns:
        output = pd.concat([output, pd.DataFrame(np.array([column, df[column].dtypes, len(df[column].unique()),
                                                           df[column].isna().sum() / df[column].shape[0]]).reshape(1, 4),
                                                 columns = ["Column", "Data Type", "Unique values", "NaN"])])

    return output
```


```python
data_jingdong_dfs[0].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>会员</th>
      <th>级别</th>
      <th>评价星级</th>
      <th>评价内容</th>
      <th>时间</th>
      <th>点赞数</th>
      <th>评论数</th>
      <th>追评时间</th>
      <th>追评内容</th>
      <th>商品属性</th>
      <th>页面网址</th>
      <th>页面标题</th>
      <th>采集时间</th>
      <th>评论字数</th>
      <th>来源平台</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>庞***纠</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>夏天最怕来姨妈了，真的闷热！所以挑选卫生巾也要好好挑选，我第一次用的时候就喜欢上了这个，很薄...</td>
      <td>2024-07-22</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.299</td>
      <td>69</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>1</th>
      <td>s***0</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>太爱这种没有护垫凑数的组合了，，都是24cm+29cm的，有好价就冲吧姐妹们，放包里放口袋里...</td>
      <td>2024-07-14</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.362</td>
      <td>62</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>2</th>
      <td>绿***双</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>一直都用苏菲的卫生巾，这款裸感S日用绵柔卫生巾也超级好用，薄薄的一片特别适合夏天用，这款还有...</td>
      <td>2024-07-02</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.431</td>
      <td>84</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>3</th>
      <td>u***2</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>挺喜欢苏菲这款卫生巾的，25厘米的长度很合适，绵柔的，还送了2片短一点的，用过他们家的东西很...</td>
      <td>2024-07-18</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.492</td>
      <td>69</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9***n</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>薄薄的一层，很舒服，量多的日子，不会湿湿潮潮的，很干爽，夏天不闷热，很透气，贴合皮肤感觉很舒...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.583</td>
      <td>66</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8***7</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>买过很多次了  包装摸着很顺滑  很舒服  拆开也很顺畅  非常方便  内里真的是丝绸般的柔...</td>
      <td>2024-07-20</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.659</td>
      <td>64</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>6</th>
      <td>m***v</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>一直在用这款，轻薄方便，还有淡淡的香味，夏天可以遮挡血腥味，十分小巧携带方便，一大箱子也可以...</td>
      <td>2024-07-22</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.768</td>
      <td>60</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>7</th>
      <td>蝸***牜</td>
      <td>NaN</td>
      <td>star5</td>
      <td>第一次购买这款苏菲裸感的，以前买的苏菲都是240或者245长的，这款日用的足够长有25cm，...</td>
      <td>2024-07-14</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.826</td>
      <td>110</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0***u</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>材质很好，质量也不错，到货也很快大品牌，用起来很放心，质量非常好，赶上活动购买非常的划算发货...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.908</td>
      <td>82</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>9</th>
      <td>好***狮</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>京东送货真的是非常的快。晚上下单，第二天就收到了。一直都用的苏菲的。这款裸感，棉柔的，用起来...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.987</td>
      <td>72</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_analysis(data_jingdong_dfs[0])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>Data Type</th>
      <th>Unique values</th>
      <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>会员</td>
      <td>object</td>
      <td>2244</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>级别</td>
      <td>object</td>
      <td>2</td>
      <td>0.1495</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价星级</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价内容</td>
      <td>object</td>
      <td>3943</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>时间</td>
      <td>object</td>
      <td>843</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>点赞数</td>
      <td>int64</td>
      <td>7</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论数</td>
      <td>int64</td>
      <td>2</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>追评时间</td>
      <td>object</td>
      <td>10</td>
      <td>0.99775</td>
    </tr>
    <tr>
      <th>0</th>
      <td>追评内容</td>
      <td>object</td>
      <td>9</td>
      <td>0.99775</td>
    </tr>
    <tr>
      <th>0</th>
      <td>商品属性</td>
      <td>object</td>
      <td>52</td>
      <td>0.0045</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面网址</td>
      <td>object</td>
      <td>8</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面标题</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>采集时间</td>
      <td>object</td>
      <td>4000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论字数</td>
      <td>int64</td>
      <td>218</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>来源平台</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌名称</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌大类</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_jingdong_dfs[0].columns
```




    Index(['会员', '级别', '评价星级', '评价内容', '时间', '点赞数', '评论数', '追评时间', '追评内容', '商品属性',
           '页面网址', '页面标题', '采集时间', '评论字数', '来源平台', '品牌名称', '品牌大类'],
          dtype='object')




```python
taobao_path = "./dataset/淘宝商品评论/"
taobao_list = os.listdir(taobao_path)
print(taobao_list)
taobao_files = [taobao_path + find_file for find_file in taobao_list]
data_taobao_dfs = [pd.read_excel(path) for path in taobao_files]
```

    ['ABC卫生巾.xlsx', 'abc安心裤.xlsx', 'abc安心裤（补）.xlsx', '七度空间卫生巾.xlsx', '七度空间安心裤.xlsx', '丹碧丝卫生棉条.xlsx', '安尔乐液体卫生巾.xlsx', '安尔乐液体卫生巾（补）.xlsx', '强生ob卫生棉条.xlsx', '护舒宝卫生巾.xlsx', '护舒宝安心裤.xlsx', '护舒宝液体卫生巾.xlsx', '苏菲卫生巾.xlsx', '苏菲卫生巾（补）.xlsx', '苏菲卫生棉条.xlsx', '苏菲安心裤.xlsx']
    


```python
for i, df in enumerate(data_taobao_dfs):
	df['来源平台'] = ['淘宝' for _ in range(len(df))]
	title = taobao_list[i].replace("（补）", '').replace(".xlsx", "")
	df['页面标题'] = [title for _ in range(len(df))]
	print(title)
	df['品牌名称'] = df['页面标题'].apply(f)
	df['品牌大类'] = df['页面标题'].apply(category)
	df['评论字数'] = df['首次评价'].apply(len)

	print(set(df['品牌名称'].tolist()))
	print(set(df['品牌大类'].tolist()))
	print("=" * 100)
```

    ABC卫生巾
    {'ABC'}
    {'卫生巾'}
    ====================================================================================================
    abc安心裤
    {'ABC'}
    {'安心裤'}
    ====================================================================================================
    abc安心裤
    {'ABC'}
    {'安心裤'}
    ====================================================================================================
    七度空间卫生巾
    {'七度空间'}
    {'卫生巾'}
    ====================================================================================================
    七度空间安心裤
    {'七度空间'}
    {'安心裤'}
    ====================================================================================================
    丹碧丝卫生棉条
    {'丹碧丝'}
    {'卫生棉条'}
    ====================================================================================================
    安尔乐液体卫生巾
    {'安尔乐'}
    {'液体卫生巾'}
    ====================================================================================================
    安尔乐液体卫生巾
    {'安尔乐'}
    {'液体卫生巾'}
    ====================================================================================================
    强生ob卫生棉条
    {'ob'}
    {'卫生棉条'}
    ====================================================================================================
    护舒宝卫生巾
    {'护舒宝'}
    {'卫生巾'}
    ====================================================================================================
    护舒宝安心裤
    {'护舒宝'}
    {'安心裤'}
    ====================================================================================================
    护舒宝液体卫生巾
    {'护舒宝'}
    {'液体卫生巾'}
    ====================================================================================================
    苏菲卫生巾
    {'苏菲'}
    {'卫生巾'}
    ====================================================================================================
    苏菲卫生巾
    {'苏菲'}
    {'卫生巾'}
    ====================================================================================================
    苏菲卫生棉条
    {'苏菲'}
    {'卫生棉条'}
    ====================================================================================================
    苏菲安心裤
    {'苏菲'}
    {'安心裤'}
    ====================================================================================================
    


```python
data_taobao_dfs[0].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>旺旺号</th>
      <th>首次评价</th>
      <th>首评时间</th>
      <th>来源平台</th>
      <th>页面标题</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
      <th>评论字数</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>s**y</td>
      <td>十几年一直用abc，薄的很舒服，比任何牌子都透气。</td>
      <td>2024-08-02</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>l**i</td>
      <td>ABC最出名的就是它的清凉经典配方,温和 健康，呵护肌肤的同时，还能赶走姨妈期的 闷热，带来...</td>
      <td>2024-05-29</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>87</td>
    </tr>
    <tr>
      <th>2</th>
      <td>t**2</td>
      <td>ABC卫生巾真的是女生的小贴心❤️，用起来超级舒服，不闷不热，吸收力超强！量大也不怕，完全不...</td>
      <td>2024-07-31</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>81</td>
    </tr>
    <tr>
      <th>3</th>
      <td>t**3</td>
      <td>夏天用ABC的可以清凉一点吧。</td>
      <td>2024-06-28</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>t**9</td>
      <td>好评好评，物流快服务好，天猫超市买东西就是好用。</td>
      <td>2024-05-27</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>24</td>
    </tr>
    <tr>
      <th>5</th>
      <td>x**o</td>
      <td>最爱用的卫生巾 好用</td>
      <td>2024-06-07</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
    </tr>
    <tr>
      <th>6</th>
      <td>d**3</td>
      <td>一直用的一款一直回购</td>
      <td>2024-08-03</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
    </tr>
    <tr>
      <th>7</th>
      <td>l**m</td>
      <td>送货上门，购物方便，省去了去超市选购的时间。</td>
      <td>2024-08-02</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>22</td>
    </tr>
    <tr>
      <th>8</th>
      <td>p**g</td>
      <td>东西质量非常好，与卖家描述的完全一致，非常满意</td>
      <td>2024-07-30</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
    </tr>
    <tr>
      <th>9</th>
      <td>今**店</td>
      <td>半日达很方便 每次都能很及时收到 价格也很便宜</td>
      <td>2024-07-29</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_analysis(data_taobao_dfs[0])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>Data Type</th>
      <th>Unique values</th>
      <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>旺旺号</td>
      <td>object</td>
      <td>150</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>首次评价</td>
      <td>object</td>
      <td>204</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>首评时间</td>
      <td>object</td>
      <td>120</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>来源平台</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面标题</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌名称</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌大类</td>
      <td>object</td>
      <td>1</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论字数</td>
      <td>int64</td>
      <td>51</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_taobao_dfs[0].columns
```




    Index(['旺旺号', '首次评价', '首评时间', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数'], dtype='object')



## 合并数据


```python
data_jingdong_dfs[0].columns
```




    Index(['会员', '级别', '评价星级', '评价内容', '时间', '点赞数', '评论数', '追评时间', '追评内容', '商品属性',
           '页面网址', '页面标题', '采集时间', '评论字数', '来源平台', '品牌名称', '品牌大类'],
          dtype='object')




```python
data_jingdong_dfs[0].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>会员</th>
      <th>级别</th>
      <th>评价星级</th>
      <th>评价内容</th>
      <th>时间</th>
      <th>点赞数</th>
      <th>评论数</th>
      <th>追评时间</th>
      <th>追评内容</th>
      <th>商品属性</th>
      <th>页面网址</th>
      <th>页面标题</th>
      <th>采集时间</th>
      <th>评论字数</th>
      <th>来源平台</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>庞***纠</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>夏天最怕来姨妈了，真的闷热！所以挑选卫生巾也要好好挑选，我第一次用的时候就喜欢上了这个，很薄...</td>
      <td>2024-07-22</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.299</td>
      <td>69</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>1</th>
      <td>s***0</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>太爱这种没有护垫凑数的组合了，，都是24cm+29cm的，有好价就冲吧姐妹们，放包里放口袋里...</td>
      <td>2024-07-14</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.362</td>
      <td>62</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>2</th>
      <td>绿***双</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>一直都用苏菲的卫生巾，这款裸感S日用绵柔卫生巾也超级好用，薄薄的一片特别适合夏天用，这款还有...</td>
      <td>2024-07-02</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.431</td>
      <td>84</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>3</th>
      <td>u***2</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>挺喜欢苏菲这款卫生巾的，25厘米的长度很合适，绵柔的，还送了2片短一点的，用过他们家的东西很...</td>
      <td>2024-07-18</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.492</td>
      <td>69</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9***n</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>薄薄的一层，很舒服，量多的日子，不会湿湿潮潮的，很干爽，夏天不闷热，很透气，贴合皮肤感觉很舒...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.583</td>
      <td>66</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8***7</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>买过很多次了  包装摸着很顺滑  很舒服  拆开也很顺畅  非常方便  内里真的是丝绸般的柔...</td>
      <td>2024-07-20</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.659</td>
      <td>64</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>6</th>
      <td>m***v</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>一直在用这款，轻薄方便，还有淡淡的香味，夏天可以遮挡血腥味，十分小巧携带方便，一大箱子也可以...</td>
      <td>2024-07-22</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.768</td>
      <td>60</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>7</th>
      <td>蝸***牜</td>
      <td>NaN</td>
      <td>star5</td>
      <td>第一次购买这款苏菲裸感的，以前买的苏菲都是240或者245长的，这款日用的足够长有25cm，...</td>
      <td>2024-07-14</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.826</td>
      <td>110</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0***u</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>材质很好，质量也不错，到货也很快大品牌，用起来很放心，质量非常好，赶上活动购买非常的划算发货...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【口袋魔法】240*78+290*14</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.908</td>
      <td>82</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
    <tr>
      <th>9</th>
      <td>好***狮</td>
      <td>PLUS会员</td>
      <td>star5</td>
      <td>京东送货真的是非常的快。晚上下单，第二天就收到了。一直都用的苏菲的。这款裸感，棉柔的，用起来...</td>
      <td>2024-07-24</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>【裸感S极上】250日用39片</td>
      <td>https://item.jd.com/100053390278.html</td>
      <td>苏菲裸感S极薄棉柔透气无感日用卫生巾姨妈巾250mm13片*3包</td>
      <td>2024-08-02 01:42:58.987</td>
      <td>72</td>
      <td>京东</td>
      <td>苏菲</td>
      <td>卫生巾</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_df = pd.DataFrame(columns=['评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数'])

for i, df in enumerate(data_taobao_dfs):
	df['评价时间'] = df['首评时间']
	df['评价内容'] = df['首次评价']
	final_df = pd.concat([final_df, df[['评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数']]], ignore_index=True)

# ['会员', '级别', '评价星级', '评价内容', '时间', '点赞数', '评论数', '追评时间', '追评内容', '商品属性',
#        '页面网址', '页面标题', '采集时间', '评论字数', '来源平台', '品牌名称', '品牌大类']

for i, df in enumerate(data_jingdong_dfs):
	df['评价时间'] = df['时间']
	final_df = pd.concat([final_df, df[['评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数']]], ignore_index=True)
```


```python
data_analysis(final_df)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>Data Type</th>
      <th>Unique values</th>
      <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>评价时间</td>
      <td>object</td>
      <td>1817</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价内容</td>
      <td>object</td>
      <td>17420</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>来源平台</td>
      <td>object</td>
      <td>2</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面标题</td>
      <td>object</td>
      <td>25</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌名称</td>
      <td>object</td>
      <td>7</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌大类</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论字数</td>
      <td>object</td>
      <td>312</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_df.to_excel("./final.xlsx")
```

# 整合数据


```python
import pandas as pd
import os
import json
import numpy as np
```


```python
import seaborn as sns
import matplotlib.pyplot as plt
import re

plt.rcParams['font.sans-serif'] = ['KaiTi', 'SimHei', 'FangSong']  # Chinese font preference: KaiTi, SimHei, FangSong
plt.rcParams['font.size'] = 12  # Font size
plt.rcParams['axes.unicode_minus'] = False  # Display minus sign correctly for Chinese characters
```


```python
json_llm = "./results.json"
final_df = pd.read_excel("./final.xlsx")
content = []
with open(json_llm, 'r', encoding="utf-8") as f:
	content = json.load(f)
	content = sorted(content, key=lambda x: x['id'])
final_df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>评价时间</th>
      <th>评价内容</th>
      <th>来源平台</th>
      <th>页面标题</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
      <th>评论字数</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2024-08-02</td>
      <td>十几年一直用abc，薄的很舒服，比任何牌子都透气。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2024-05-29</td>
      <td>ABC最出名的就是它的清凉经典配方,温和 健康，呵护肌肤的同时，还能赶走姨妈期的 闷热，带来...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>87</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2024-07-31</td>
      <td>ABC卫生巾真的是女生的小贴心❤️，用起来超级舒服，不闷不热，吸收力超强！量大也不怕，完全不...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>81</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2024-06-28</td>
      <td>夏天用ABC的可以清凉一点吧。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2024-05-27</td>
      <td>好评好评，物流快服务好，天猫超市买东西就是好用。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>24</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>2024-06-07</td>
      <td>最爱用的卫生巾 好用</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2024-08-03</td>
      <td>一直用的一款一直回购</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>2024-08-02</td>
      <td>送货上门，购物方便，省去了去超市选购的时间。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>22</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>2024-07-30</td>
      <td>东西质量非常好，与卖家描述的完全一致，非常满意</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>2024-07-29</td>
      <td>半日达很方便 每次都能很及时收到 价格也很便宜</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_df.columns
```




    Index(['Unnamed: 0', '评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数'], dtype='object')




```python
final_df['输出结果'] = [i['content'] + '\n' for i in content]
```


```python
final_df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>评价时间</th>
      <th>评价内容</th>
      <th>来源平台</th>
      <th>页面标题</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
      <th>评论字数</th>
      <th>输出结果</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2024-08-02</td>
      <td>十几年一直用abc，薄的很舒服，比任何牌子都透气。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>25</td>
      <td>\n#### 输入:\n**产品类别**: 卫生巾\n**评论**: “十几年一直用abc，...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2024-05-29</td>
      <td>ABC最出名的就是它的清凉经典配方,温和 健康，呵护肌肤的同时，还能赶走姨妈期的 闷热，带来...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>87</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉经典配方、温和、健康、...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2024-07-31</td>
      <td>ABC卫生巾真的是女生的小贴心❤️，用起来超级舒服，不闷不热，吸收力超强！量大也不怕，完全不...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>81</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 吸收力超强、量大、不侧漏\...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2024-06-28</td>
      <td>夏天用ABC的可以清凉一点吧。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>15</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉\n   - 使用体验...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2024-05-27</td>
      <td>好评好评，物流快服务好，天猫超市买东西就是好用。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>24</td>
      <td>\n### 输入:\n**产品类别**: 卫生巾\n**评论**: “好评好评，物流快服务好...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>2024-06-07</td>
      <td>最爱用的卫生巾 好用</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 好用\n   - 使用体验...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2024-08-03</td>
      <td>一直用的一款一直回购</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>2024-08-02</td>
      <td>送货上门，购物方便，省去了去超市选购的时间。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>22</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>2024-07-30</td>
      <td>东西质量非常好，与卖家描述的完全一致，非常满意</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 质量好、描述一致\n   ...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>2024-07-29</td>
      <td>半日达很方便 每次都能很及时收到 价格也很便宜</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 定义提取信息的函数
def extract_keywords_and_score(text):
    quality_pattern = r"- 产品质量相关:\s*(.*?)\n"
    experience_pattern = r"- 使用体验相关:\s*(.*?)\n"
    packaging_pattern = r"- 包装相关:\s*(.*?)\n"
    price_pattern = r"- 价格相关:\s*(.*?)\n"
    sentiment_pattern = r"- 评分:\s*(\d)"

    quality_keywords = re.findall(quality_pattern, text, re.DOTALL)
    experience_keywords = re.findall(experience_pattern, text, re.DOTALL)
    packaging_keywords = re.findall(packaging_pattern, text, re.DOTALL)
    price_keywords = re.findall(price_pattern, text, re.DOTALL)
    sentiment_score = re.findall(sentiment_pattern, text, re.DOTALL)

    return {
        '产品质量关键词': quality_keywords[0] if quality_keywords else '无',
        '使用体验关键词': experience_keywords[0] if experience_keywords else '无',
        '包装关键词': packaging_keywords[0] if packaging_keywords else '无',
        '价格关键词': price_keywords[0] if price_keywords else '无',
        '情感评分': int(sentiment_score[0].replace("星", "")) if sentiment_score else '无'
    }


df_keywords = final_df['输出结果'].apply(extract_keywords_and_score)
df_extracted = pd.concat([final_df, pd.DataFrame(df_keywords.tolist())], axis=1)
```


```python
df_extracted.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>评价时间</th>
      <th>评价内容</th>
      <th>来源平台</th>
      <th>页面标题</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
      <th>评论字数</th>
      <th>输出结果</th>
      <th>产品质量关键词</th>
      <th>使用体验关键词</th>
      <th>包装关键词</th>
      <th>价格关键词</th>
      <th>情感评分</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2024-08-02</td>
      <td>十几年一直用abc，薄的很舒服，比任何牌子都透气。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>25</td>
      <td>\n#### 输入:\n**产品类别**: 卫生巾\n**评论**: “十几年一直用abc，...</td>
      <td>薄、透气</td>
      <td>舒服</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2024-05-29</td>
      <td>ABC最出名的就是它的清凉经典配方,温和 健康，呵护肌肤的同时，还能赶走姨妈期的 闷热，带来...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>87</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉经典配方、温和、健康、...</td>
      <td>清凉经典配方、温和、健康、呵护肌肤、赶走闷热、舒爽、通透</td>
      <td>不习惯、真的香、轻透</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2024-07-31</td>
      <td>ABC卫生巾真的是女生的小贴心❤️，用起来超级舒服，不闷不热，吸收力超强！量大也不怕，完全不...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>81</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 吸收力超强、量大、不侧漏\...</td>
      <td>吸收力超强、量大、不侧漏</td>
      <td>超级舒服、不闷不热、稳稳的、幸福感爆棚</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2024-06-28</td>
      <td>夏天用ABC的可以清凉一点吧。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>15</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉\n   - 使用体验...</td>
      <td>清凉</td>
      <td>无</td>
      <td>无</td>
      <td>无</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2024-05-27</td>
      <td>好评好评，物流快服务好，天猫超市买东西就是好用。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>24</td>
      <td>\n### 输入:\n**产品类别**: 卫生巾\n**评论**: “好评好评，物流快服务好...</td>
      <td>无</td>
      <td>天猫超市买东西好用</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>2024-06-07</td>
      <td>最爱用的卫生巾 好用</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 好用\n   - 使用体验...</td>
      <td>好用</td>
      <td>[无相关关键词]</td>
      <td>[无相关关键词]</td>
      <td>[无相关关键词]</td>
      <td>5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2024-08-03</td>
      <td>一直用的一款一直回购</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>一直用、回购</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>2024-08-02</td>
      <td>送货上门，购物方便，省去了去超市选购的时间。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>22</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>购物方便、省时</td>
      <td>无</td>
      <td>无</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>2024-07-30</td>
      <td>东西质量非常好，与卖家描述的完全一致，非常满意</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 质量好、描述一致\n   ...</td>
      <td>质量好、描述一致</td>
      <td>无</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>2024-07-29</td>
      <td>半日达很方便 每次都能很及时收到 价格也很便宜</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>半日达方便 及时</td>
      <td>无</td>
      <td>便宜</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
def data_analysis(df):
    # Display the situation of data fields, such as data type, unique values, and the proportion of missing data.
    output = pd.DataFrame(columns = ["Column", "Data Type", "Unique values", "NaN"])

    for column in df.columns:
        output = pd.concat([output, pd.DataFrame(np.array([column, df[column].dtypes, len(df[column].unique()),
                                                           df[column].isna().sum() / df[column].shape[0]]).reshape(1, 4),
                                                 columns = ["Column", "Data Type", "Unique values", "NaN"])])

    return output
```


```python
df_extracted.columns
```




    Index(['Unnamed: 0', '评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数',
           '输出结果', '产品质量关键词', '使用体验关键词', '包装关键词', '价格关键词', '情感评分'],
          dtype='object')




```python
data_analysis(df_extracted)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>Data Type</th>
      <th>Unique values</th>
      <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Unnamed: 0</td>
      <td>int64</td>
      <td>17966</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价时间</td>
      <td>object</td>
      <td>1817</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价内容</td>
      <td>object</td>
      <td>17420</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>来源平台</td>
      <td>object</td>
      <td>2</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面标题</td>
      <td>object</td>
      <td>25</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌名称</td>
      <td>object</td>
      <td>7</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌大类</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论字数</td>
      <td>int64</td>
      <td>312</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>输出结果</td>
      <td>object</td>
      <td>17596</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>产品质量关键词</td>
      <td>object</td>
      <td>12181</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>使用体验关键词</td>
      <td>object</td>
      <td>11458</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>包装关键词</td>
      <td>object</td>
      <td>2175</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>价格关键词</td>
      <td>object</td>
      <td>5090</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>情感评分</td>
      <td>object</td>
      <td>6</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
set(df_extracted['情感评分'])
```




    {1, 2, 3, 4, 5, '无'}



### 不处理 '无' 的情况


```python
# 假设你的DataFrame名称为df，并且情感评分列为'情感评分'
plt.figure(figsize=(10, 6))
sns.countplot(data=df_extracted, x='情感评分', palette='viridis')

# 设置图表标题和标签
plt.title('情感评分分布统计')
plt.xlabel('情感评分')
plt.ylabel('数量')

# 显示图表
plt.show()
```

    C:\Users\Admin\AppData\Local\Temp\ipykernel_48888\2610811121.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=df_extracted, x='情感评分', palette='viridis')
    C:\Users\Admin\AppData\Roaming\Python\Python39\site-packages\pandas\core\algorithms.py:518: DeprecationWarning: np.find_common_type is deprecated.  Please use `np.result_type` or `np.promote_types`.
    See https://numpy.org/devdocs/release/1.25.0-notes.html and the docs for more information.  (Deprecated NumPy 1.25)
      common = np.find_common_type([values.dtype, comps_array.dtype], [])
    C:\Users\Admin\AppData\Roaming\Python\Python39\site-packages\pandas\core\algorithms.py:518: DeprecationWarning: np.find_common_type is deprecated.  Please use `np.result_type` or `np.promote_types`.
    See https://numpy.org/devdocs/release/1.25.0-notes.html and the docs for more information.  (Deprecated NumPy 1.25)
      common = np.find_common_type([values.dtype, comps_array.dtype], [])
    


    
![png](output_36_1.png)
    


### 情感评分大致


```python
# 定义提取信息的函数
def extract_keywords_and_score(text):
    quality_pattern = r"- 产品质量相关:\s*(.*?)\n"
    experience_pattern = r"- 使用体验相关:\s*(.*?)\n"
    packaging_pattern = r"- 包装相关:\s*(.*?)\n"
    price_pattern = r"- 价格相关:\s*(.*?)\n"
    sentiment_pattern = r"- 评分:\s*(\d)"

    quality_keywords = re.findall(quality_pattern, text, re.DOTALL)
    experience_keywords = re.findall(experience_pattern, text, re.DOTALL)
    packaging_keywords = re.findall(packaging_pattern, text, re.DOTALL)
    price_keywords = re.findall(price_pattern, text, re.DOTALL)
    sentiment_score = re.findall(sentiment_pattern, text, re.DOTALL)

    return {
        '产品质量关键词': quality_keywords[0] if quality_keywords else '无',
        '使用体验关键词': experience_keywords[0] if experience_keywords else '无',
        '包装关键词': packaging_keywords[0] if packaging_keywords else '无',
        '价格关键词': price_keywords[0] if price_keywords else '无',
        '情感评分': int(sentiment_score[0].replace("星", "")) if sentiment_score else 3
    }


df_keywords = final_df['输出结果'].apply(extract_keywords_and_score)
df_extracted = pd.concat([final_df, pd.DataFrame(df_keywords.tolist())], axis=1)
```


```python
data_analysis(df_extracted)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column</th>
      <th>Data Type</th>
      <th>Unique values</th>
      <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Unnamed: 0</td>
      <td>int64</td>
      <td>17966</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价时间</td>
      <td>object</td>
      <td>1817</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评价内容</td>
      <td>object</td>
      <td>17420</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>来源平台</td>
      <td>object</td>
      <td>2</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>页面标题</td>
      <td>object</td>
      <td>25</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌名称</td>
      <td>object</td>
      <td>7</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>品牌大类</td>
      <td>object</td>
      <td>4</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>评论字数</td>
      <td>int64</td>
      <td>312</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>输出结果</td>
      <td>object</td>
      <td>17596</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>产品质量关键词</td>
      <td>object</td>
      <td>12181</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>使用体验关键词</td>
      <td>object</td>
      <td>11458</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>包装关键词</td>
      <td>object</td>
      <td>2175</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>价格关键词</td>
      <td>object</td>
      <td>5090</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>情感评分</td>
      <td>int64</td>
      <td>5</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 统计每个情感评分的数量
score_counts = df_extracted['情感评分'].value_counts().sort_index()

# 创建柱状图
plt.figure(figsize=(10, 10))
sns.barplot(x=score_counts.index, y=score_counts.values, palette="Blues_d")

# 显示每个柱子的具体数值
for index, value in enumerate(score_counts.values):
    plt.text(index, value + 200, str(value), ha='center', va='bottom', fontsize=12)

# 添加标题和标签
plt.title('情感评分分布', fontsize=16)
plt.xlabel('情感评分', fontsize=14)
plt.ylabel('数量', fontsize=14)
```

    C:\Users\Admin\AppData\Local\Temp\ipykernel_48888\3403881531.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=score_counts.index, y=score_counts.values, palette="Blues_d")
    C:\Users\Admin\AppData\Roaming\Python\Python39\site-packages\pandas\core\algorithms.py:518: DeprecationWarning: np.find_common_type is deprecated.  Please use `np.result_type` or `np.promote_types`.
    See https://numpy.org/devdocs/release/1.25.0-notes.html and the docs for more information.  (Deprecated NumPy 1.25)
      common = np.find_common_type([values.dtype, comps_array.dtype], [])
    C:\Users\Admin\AppData\Roaming\Python\Python39\site-packages\pandas\core\algorithms.py:518: DeprecationWarning: np.find_common_type is deprecated.  Please use `np.result_type` or `np.promote_types`.
    See https://numpy.org/devdocs/release/1.25.0-notes.html and the docs for more information.  (Deprecated NumPy 1.25)
      common = np.find_common_type([values.dtype, comps_array.dtype], [])
    




    Text(0, 0.5, '数量')




    
![png](output_40_2.png)
    


# 分析数据

## 时间分布


```python
# 按月度统计评论数量
df = df_extracted.copy()
# 先将 '评价时间' 列转换为 datetime 类型
df['time'] = pd.to_datetime(df['评价时间'], errors='coerce')

# 转换成功后再执行后续操作，按季度统计
quarterly_counts = df['time'].dt.to_period('Q').value_counts().sort_index()

# 绘制评论的时间分布柱状图
plt.figure(figsize=(24, 12))
quarterly_counts.plot(kind='bar', color='skyblue')

# 设置图表标题和标签
plt.title('电商平台女性日用品商品汇总评论的时间分布（按季度）')
plt.xlabel('时间（季度）')
plt.ylabel('评论数量')

# 显示具体的数字
for index, value in enumerate(quarterly_counts):
    plt.text(index, value + 0.5, str(value), ha='center', va='bottom', fontsize=18)

plt.grid(True, axis='y')  # 仅显示Y轴的网格线
plt.show()
```


    
![png](output_42_0.png)
    



```python
# 按月度统计评论数量
df = df_extracted.copy()
# 先将 '评价时间' 列转换为 datetime 类型
df['time'] = pd.to_datetime(df['评价时间'], errors='coerce')

# 转换成功后再执行后续操作，按季度统计
quarterly_counts = df['time'].dt.to_period('Y').value_counts().sort_index()

# 绘制评论的时间分布柱状图
plt.figure(figsize=(24, 12))
quarterly_counts.plot(kind='bar', color='skyblue')

# 设置图表标题和标签
plt.title('电商平台女性日用品商品汇总评论的时间分布（按年）')
plt.xlabel('时间（年）')
plt.ylabel('评论数量')

# 显示具体的数字
for index, value in enumerate(quarterly_counts):
    plt.text(index, value + 0.5, str(value), ha='center', va='bottom', fontsize=18)

plt.grid(True, axis='y')  # 仅显示Y轴的网格线
plt.show()
```


    
![png](output_43_0.png)
    



```python
# 按平台分组
platforms = df['来源平台'].unique()

# 为每个平台绘制一个柱状图
for platform in platforms:
    platform_df = df[df['来源平台'] == platform]
    quarterly_counts = platform_df['time'].dt.to_period('Q').value_counts().sort_index()

    # 绘制评论的时间分布柱状图
    plt.figure(figsize=(24, 12))
    quarterly_counts.plot(kind='bar', color='skyblue')

    # 设置图表标题和标签
    plt.title(f'电商平台 {platform} 女性日用品商品汇总评论的季度分布')
    plt.xlabel('时间（季度）')
    plt.ylabel('评论数量')

    # 显示具体的数字
    for index, value in enumerate(quarterly_counts):
        plt.text(index, value + 0.5, str(value), ha='center', va='bottom', fontsize=20)

    plt.grid(True, axis='y')  # 仅显示Y轴的网格线
    plt.show()
```


    
![png](output_44_0.png)
    



    
![png](output_44_1.png)
    



```python
# 获取所有商品大类
categories = df['品牌大类'].unique()

# 为每个商品大类绘制单独的图
for category in categories:
    plt.figure(figsize=(24, 12))

    # 按商品大类和季度统计评论数量
    quarterly_counts_by_category = df[df['品牌大类'] == category]['time'].dt.to_period('Q').value_counts().sort_index()

    # 绘制柱状图，颜色根据商品大类设置不同颜色
    quarterly_counts_by_category.plot(kind='bar', color=plt.cm.get_cmap('tab20')(categories.tolist().index(category)), label=category)

    # 设置图表标题和标签
    plt.title(f'{category}的女性日用品用户评论的时间分布')
    plt.xlabel('时间（季度）')
    plt.ylabel('评论数量')

    # 显示图例
    plt.legend(title='商品大类')
    # 显示具体的数字
    for index, value in enumerate(quarterly_counts_by_category):
        plt.text(index, value + 0.5, str(value), ha='center', va='bottom', fontsize=20)

    # 显示网格
    plt.grid(True, axis='y')

    # 显示图表
    plt.show()
```


    
![png](output_45_0.png)
    



    
![png](output_45_1.png)
    



    
![png](output_45_2.png)
    



    
![png](output_45_3.png)
    



```python
# 获取所有平台
platforms = df['来源平台'].unique()

# 获取所有商品大类
categories = df['品牌大类'].unique()

# 为每个平台和商品大类绘制单独的图
for platform in platforms:
    for category in categories:
        plt.figure(figsize=(24, 7))

        # 按平台和商品大类按季度统计评论数量
        quarterly_counts_by_category = df[(df['来源平台'] == platform) & (df['品牌大类'] == category)]['time'].dt.to_period('Q').value_counts().sort_index()

        # 绘制柱状图，颜色根据商品大类设置不同颜色
        ax = quarterly_counts_by_category.plot(kind='bar', color=plt.cm.get_cmap('tab20')(categories.tolist().index(category)), label=f'{platform} - {category}')

        # 设置图表标题和标签
        plt.title(f'{platform}平台下{category}的女性日用品用户评论的时间分布')
        plt.xlabel('时间（季度）')
        plt.ylabel('评论数量')

        # 在每个柱子上显示具体的数字
        for index, value in enumerate(quarterly_counts_by_category):
            ax.text(index, value + 0.5, str(value), ha='center', va='bottom', fontsize=12)

        # 显示图例
        plt.legend(title='商品大类')

        # 显示网格
        plt.grid(True, axis='y')

        # 显示图表
        plt.show()

```


    
![png](output_46_0.png)
    



    
![png](output_46_1.png)
    



    
![png](output_46_2.png)
    



    
![png](output_46_3.png)
    



    
![png](output_46_4.png)
    



    
![png](output_46_5.png)
    



    
![png](output_46_6.png)
    



    
![png](output_46_7.png)
    


# 评论字数情况


```python
df.columns
```




    Index(['Unnamed: 0', '评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数',
           '输出结果', '产品质量关键词', '使用体验关键词', '包装关键词', '价格关键词', '情感评分', 'time'],
          dtype='object')




```python
# 筛选出卫生巾类别的数据
df_weishengjin = df[df['品牌大类'] == '卫生巾']

# 获取所有品牌
brands = df_weishengjin['品牌名称'].unique()

# 获取所有平台
platforms = ['京东', '淘宝']  # 可以根据你的数据调整平台名称

# 为每个品牌绘制单独的图
for brand in brands:
    plt.figure(figsize=(24, 12))

    # 初始化一个字典来存储平台的评论数量
    platform_counts = {}

    # 按平台统计该品牌的季度评论数量
    for platform in platforms:
        quarterly_counts_by_platform = df_weishengjin[(df_weishengjin['来源平台'] == platform) & (df_weishengjin['品牌名称'] == brand)]['time'].dt.to_period('Q').value_counts().sort_index()
        platform_counts[platform] = quarterly_counts_by_platform

    # 将平台数据转换为DataFrame，方便绘图
    df_platform_counts = pd.DataFrame(platform_counts).fillna(0)

    # 绘制柱状图
    df_platform_counts.plot(kind='bar', color=['skyblue', 'orange'], ax=plt.gca())

    # 设置图表标题和标签
    plt.title(f'{brand}品牌在不同平台的评论时间分布', fontsize=18)
    plt.xlabel('时间（季度）', fontsize=18)
    plt.ylabel('评论数量', fontsize=18)

    # 显示图例
    plt.legend(title='平台', fontsize=18, title_fontsize=18)

    # 显示具体的数字
    for i in range(len(df_platform_counts)):
        for j, platform in enumerate(platforms):
            plt.text(i - 0.1 + 0.2 * j, df_platform_counts.iloc[i, j], str(int(df_platform_counts.iloc[i, j])),
                 ha='center', va='bottom', fontsize=18, fontweight='bold')

    # 显示网格
    plt.grid(True, axis='y')

    # 显示图表
    plt.show()
```


    
![png](output_49_0.png)
    



    
![png](output_49_1.png)
    



    
![png](output_49_2.png)
    



    
![png](output_49_3.png)
    



```python
df.columns
```




    Index(['Unnamed: 0', '评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数',
           '输出结果', '产品质量关键词', '使用体验关键词', '包装关键词', '价格关键词', '情感评分', 'time'],
          dtype='object')




```python
colors = {'京东': 'skyblue', '淘宝': 'lightgreen'}
# 筛选出卫生巾类别的数据
category_list = list(set(df['品牌大类']))

for category_name in category_list:
	df_weishengjin = df[df['品牌大类'] == category_name]

	# 获取所有品牌
	brands = df_weishengjin['品牌名称'].unique()

	# 获取所有平台
	platforms = ['京东', '淘宝']  # 根据数据的实际平台名调整

	# 初始化数据结构以存储每个品牌的评论字数数据
	brand_platform_data = {}

	for brand in brands:
	    brand_platform_data[brand] = []
	    for platform in platforms:
	        # 获取该品牌在该平台上的评论字数，并按季度汇总
	        word_counts_by_platform = df_weishengjin[(df_weishengjin['来源平台'] == platform) &
	                                                 (df_weishengjin['品牌名称'] == brand)]['评论字数']
	        brand_platform_data[brand].append(word_counts_by_platform)

	# 绘制箱线图
	plt.figure(figsize=(18, 12))

	# 用于控制不同品牌的位置
	positions = []

	for brand_index, brand in enumerate(brands):
	    # 确定箱线图的横坐标位置
	    positions.extend([brand_index * 2 + i * 0.5 for i in range(len(platforms))])

	    # 绘制不同平台的箱线图
	    for i, platform in enumerate(platforms):
	        plt.boxplot(brand_platform_data[brand][i], positions=[brand_index * 2 + i * 0.5], widths=0.4,
	                    patch_artist=True, boxprops=dict(facecolor=colors[platforms[i]]), medianprops=dict(color='red'))

	# 设置图表标题和标签
	plt.title(f'{category_name}不同品牌在不同平台的评论字数分布', fontsize=18)
	plt.xlabel('品牌名称', fontsize=18)
	plt.ylabel('评论字数', fontsize=18)
	plt.xticks([i * 2 + 0.25 for i in range(len(brands))], brands)  # 使品牌名与箱线图居中对齐

	# 添加图例
	handles = [plt.Line2D([0], [0], color=colors[platform], lw=4) for platform in platforms]
	plt.legend(handles, platforms, title="平台", fontsize=14, title_fontsize=16)

	# 显示网格
	plt.grid(True, axis='y')

	# 显示图表
	plt.show()
```


    
![png](output_51_0.png)
    



    
![png](output_51_1.png)
    



    
![png](output_51_2.png)
    



    
![png](output_51_3.png)
    


# 评分情况


```python
brand = list(set(df['品牌名称']))
brand
```




    ['安尔乐', 'ABC', '苏菲', '护舒宝', 'ob', '丹碧丝', '七度空间']




```python
# 假设 df_weishengjin 已经包含所有数据
# 筛选出卫生巾类别的数据
# 获取所有品牌
# 筛选出卫生巾类别的数据
category_list = list(set(df['品牌大类']))

for category_name in category_list:
	df_weishengjin = df[df['品牌大类'] == category_name]
	brands = df_weishengjin['品牌名称'].unique()

	# 定义情感评分的范围
	ratings = [1, 2, 3, 4, 5]

	# 定义颜色映射
	colors = {1: 'blue', 2: 'orange', 3: 'green', 4: 'red', 5: 'purple'}

	# 为每个品牌绘制柱状图
	plt.figure(figsize=(18, 12))

	bar_width = 0.15  # 每个柱子的宽度
	space_between_brands = 0.5  # 品牌之间的间隔

	for brand_index, brand in enumerate(brands):
	    # 初始化存储每个评分的评论数量
	    rating_counts = []

	    for rating in ratings:
	        # 计算每个评分的评论数量
	        count = df_weishengjin[(df_weishengjin['品牌名称'] == brand) & (df_weishengjin['情感评分'] == rating)].shape[0]
	        rating_counts.append(count)

	    # 计算每个柱子的X轴位置
	    positions = np.arange(len(ratings)) * bar_width + brand_index * (bar_width * len(ratings) + space_between_brands)

	    # 绘制每个情感评分的柱子
	    for i, rating in enumerate(ratings):
	        plt.bar(positions[i], rating_counts[i], color=colors[rating], width=bar_width, label=f'{rating}星' if brand_index == 0 else "")
			 # 在每个柱子上显示具体的数值
	        plt.text(positions[i], rating_counts[i] + 0.5, str(rating_counts[i]), ha='center', va='bottom', fontsize=16)

	# 设置图表标题和标签
	plt.title(f'{category_name}在不同情感评分下的评论数量分布(GLM-4-9B-Chat大模型打分)', fontsize=20)
	plt.xlabel('品牌及情感评分', fontsize=20)
	plt.ylabel('评论数量', fontsize=20)

	# 设置x轴的刻度标签，使品牌名与柱状图居中对齐
	brand_labels = []
	for brand in brands:
	    for rating in ratings:
	        brand_labels.append(f'{rating}星')

	# 生成x轴标签
	tick_positions = [i * (bar_width * len(ratings) + space_between_brands) + (bar_width * len(ratings) - bar_width) / 2 for i in range(len(brands))]
	plt.xticks(tick_positions, brands, rotation=0, ha='right', fontsize=20)

	# 添加图例
	plt.legend(title="评分", fontsize=14, title_fontsize=16)

	# 显示网格
	plt.grid(True, axis='y')

	# 显示图表
	plt.show()
```


    
![png](output_54_0.png)
    



    
![png](output_54_1.png)
    



    
![png](output_54_2.png)
    



    
![png](output_54_3.png)
    



```python
# 假设 df_weishengjin 已经包含所有数据
category_list = list(set(df['品牌大类']))

# 定义颜色映射
brand_colors = {
    '安尔乐': 'blue',
    '七度空间': 'orange',
    'ABC': 'green',
    '护舒宝': 'red',
    '丹碧丝': 'purple',
    '苏菲': 'pink',
    'ob': 'cyan'
}

# 创建一个包含四个子图的图表
fig, axes = plt.subplots(2, 2, figsize=(18, 20))  # 2x2网格布局

# 平铺模式下的索引
axes = axes.flatten()

for idx, category_name in enumerate(category_list):
    df_weishengjin = df[df['品牌大类'] == category_name]
    brands = df_weishengjin['品牌名称'].unique()

    # 为每个品牌计算情感评分的平均值
    average_ratings = []
    for brand in brands:
        avg_rating = df_weishengjin[df_weishengjin['品牌名称'] == brand]['情感评分'].mean()
        average_ratings.append(avg_rating)

    # 计算每个柱子的X轴位置
    positions = np.arange(len(brands))

    # 获取品牌对应的颜色
    colors = [brand_colors.get(brand, 'gray') for brand in brands]

    # 在子图上绘制柱状图
    axes[idx].bar(positions, average_ratings, color=colors, width=0.6)

    # 在每个柱子上显示具体的平均分数值
    for i, avg_rating in enumerate(average_ratings):
        axes[idx].text(positions[i], avg_rating + 0.05, f'{avg_rating:.2f}', ha='center', va='bottom', fontsize=20)

    # 设置子图的标题和标签
    axes[idx].set_title(f'{category_name}品牌评论在GLM-4-9B-Chat\n大模型打分所得平均分', fontsize=16)
    axes[idx].set_xlabel('品牌名称', fontsize=20)
    axes[idx].set_ylabel('平均评分', fontsize=20)

    # 设置X轴刻度标签为品牌名称
    axes[idx].set_xticks(positions)
    axes[idx].set_xticklabels(brands, rotation=0, ha='right', fontsize=20)

    # 显示网格
    axes[idx].grid(True, axis='y')

# 调整子图之间的间距
plt.tight_layout()

# 显示合并后的图表
plt.show()

```


    
![png](output_55_0.png)
    


# 关键词情况


```python
df.columns
```




    Index(['Unnamed: 0', '评价时间', '评价内容', '来源平台', '页面标题', '品牌名称', '品牌大类', '评论字数',
           '输出结果', '产品质量关键词', '使用体验关键词', '包装关键词', '价格关键词', '情感评分', 'time',
           '关键词列表'],
          dtype='object')




```python
import re
from LAC import LAC
from wordcloud import WordCloud
```


```python
# 假设 df_weishengjin 是你提供的 DataFrame
lac = LAC(mode='seg', use_cuda=True)

# 定义一个函数来切分句子
def split_sentences(text):
    # 通过标点符号进行切分
    sentences = re.split(r'[，。！？、,.!?]', text)
    return [s.strip() for s in sentences if s.strip()]

# 定义一个函数使用LAC模型对句子进行分词
def lac_cut_sentences(sentences):
    words = []
    for sentence in sentences:
        words.extend(lac.run(sentence))
    return words

# 对 DataFrame 进行关键词切分和分词处理
df['关键词列表'] = df['产品质量关键词'].apply(lambda x: lac_cut_sentences(split_sentences(x)))
df['关键词列表'] = df['关键词列表'] + df['使用体验关键词'].apply(lambda x: lac_cut_sentences(split_sentences(x)))
df['关键词列表'] = df['关键词列表'] + df['包装关键词'].apply(lambda x: lac_cut_sentences(split_sentences(x)))
df['关键词列表'] = df['关键词列表'] + df['价格关键词'].apply(lambda x: lac_cut_sentences(split_sentences(x)))
```


```python
# 初始化LAC分词器
from nltk.corpus import stopwords
chinese_stopwords = stopwords.words('chinese')
stopwords_path = './stopwords.txt'
# 读取文件并将词汇添加到停用词列表中
with open(stopwords_path, 'r', encoding='utf-8') as file:
    words_from_file = file.read().split()

# 添加文件中的词汇到停用词列表中
chinese_stopwords.extend(words_from_file)

# 去重停用词列表中的词汇
stopwords = list(set(chinese_stopwords)) + ['无无', '无']
```


```python
# 按品牌大类划分数据，并绘制词云
category_list = df['品牌大类'].unique()

# 设定字体路径
font_path = 'C:/Windows/Fonts/simkai.ttf'  # 请将路径替换为你本地的字体路径

for category in category_list:
    # 筛选出该类别的数据
    df_category = df[df['品牌大类'] == category]

    # 高星评论
    high_rating_words = df_category[df_category['情感评分'] >= 4]['关键词列表'].sum()
    high_rating_words = [word for word in high_rating_words if len(word) >= 2]
    # 差评评论
    low_rating_words = df_category[df_category['情感评分'] <= 2]['关键词列表'].sum()
    low_rating_words = [word for word in low_rating_words if len(word) >= 2]

    # 生成高星评论的词云图
    high_rating_wordcloud = WordCloud(font_path=font_path, width=1800, height=1800, background_color='white').generate(' '.join(high_rating_words))

    # 生成中差评评论的词云图
    low_rating_wordcloud = WordCloud(font_path=font_path, width=1800, height=1800, background_color='white').generate(' '.join(low_rating_words))

    # 绘制词云图
    plt.figure(figsize=(36, 18))

    # 高星词云
    plt.subplot(1, 2, 1)
    plt.imshow(high_rating_wordcloud, interpolation='bilinear')
    plt.title(f'{category} 好评词云图', fontsize=80)
    plt.axis('off')

    # 中差评词云
    plt.subplot(1, 2, 2)
    plt.imshow(low_rating_wordcloud, interpolation='bilinear')
    plt.title(f'{category} 差评词云图', fontsize=80)
    plt.axis('off')

    # 显示图像
    plt.tight_layout()
    plt.show()
```


    
![png](output_61_0.png)
    



    
![png](output_61_1.png)
    



    
![png](output_61_2.png)
    



    
![png](output_61_3.png)
    



```python
# 按品牌大类划分数据，并绘制Top 10关键词柱状图
from collections import Counter

category_list = df['品牌大类'].unique()

# 设定字体路径
font_path = 'C:/Windows/Fonts/simkai.ttf'  # 请将路径替换为你本地的字体路径

for category in category_list:
    # 筛选出该类别的数据
    df_category = df[df['品牌大类'] == category]

    # 高星评论
    high_rating_words = df_category[df_category['情感评分'] >= 4]['关键词列表'].sum()
    high_rating_words = [word for word in high_rating_words if len(word) >= 2]

    # 差评评论
    low_rating_words = df_category[df_category['情感评分'] <= 2]['关键词列表'].sum()
    low_rating_words = [word for word in low_rating_words if len(word) >= 2]

    # 统计词频并获取Top 10关键词
    high_rating_top10 = Counter(high_rating_words).most_common(20)
    low_rating_top10 = Counter(low_rating_words).most_common(20)

    # 绘制Top 10关键词柱状图
    plt.figure(figsize=(36, 18))

    # 高星Top 10关键词
    plt.subplot(1, 2, 1)
    words, counts = zip(*high_rating_top10)
    bars = plt.barh(words, counts, color='skyblue')
    plt.title(f'{category} 好评Top 20关键词', fontsize=40)
    plt.xlabel('出现次数', fontsize=40)
    plt.ylabel('关键词', fontsize=40)
    plt.gca().invert_yaxis()  # 关键词顺序从上到下排列

    # 添加出现次数的数字标签
    for bar in bars:
        plt.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2,
                 f'{int(bar.get_width())}', va='center', ha='left', fontsize=30)

    # 调整关键字字体大小
    for tick in plt.gca().get_yticklabels():
        tick.set_fontsize(30)  # 将关键字字体大小设置为30

    # 差评Top 10关键词
    plt.subplot(1, 2, 2)
    words, counts = zip(*low_rating_top10)
    bars = plt.barh(words, counts, color='lightcoral')
    plt.title(f'{category} 差评Top 20关键词', fontsize=40)
    plt.xlabel('出现次数', fontsize=40)
    plt.ylabel('关键词', fontsize=40)
    plt.gca().invert_yaxis()  # 关键词顺序从上到下排列

    # 添加出现次数的数字标签
    for bar in bars:
        plt.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2,
                 f'{int(bar.get_width())}', va='center', ha='left', fontsize=30)

    # 调整关键字字体大小
    for tick in plt.gca().get_yticklabels():
        tick.set_fontsize(30)  # 将关键字字体大小设置为30

    # 显示图像
    plt.tight_layout()
    plt.show()
```


    
![png](output_62_0.png)
    



    
![png](output_62_1.png)
    



    
![png](output_62_2.png)
    



    
![png](output_62_3.png)
    



```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>评价时间</th>
      <th>评价内容</th>
      <th>来源平台</th>
      <th>页面标题</th>
      <th>品牌名称</th>
      <th>品牌大类</th>
      <th>评论字数</th>
      <th>输出结果</th>
      <th>产品质量关键词</th>
      <th>使用体验关键词</th>
      <th>包装关键词</th>
      <th>价格关键词</th>
      <th>情感评分</th>
      <th>time</th>
      <th>关键词列表</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2024-08-02</td>
      <td>十几年一直用abc，薄的很舒服，比任何牌子都透气。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>25</td>
      <td>\n#### 输入:\n**产品类别**: 卫生巾\n**评论**: “十几年一直用abc，...</td>
      <td>薄、透气</td>
      <td>舒服</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-08-02</td>
      <td>[薄, 透气, 舒服, 无, 无]</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2024-05-29</td>
      <td>ABC最出名的就是它的清凉经典配方,温和 健康，呵护肌肤的同时，还能赶走姨妈期的 闷热，带来...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>87</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉经典配方、温和、健康、...</td>
      <td>清凉经典配方、温和、健康、呵护肌肤、赶走闷热、舒爽、通透</td>
      <td>不习惯、真的香、轻透</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-05-29</td>
      <td>[清凉, 经典, 配方, 温和, 健康, 呵护, 肌肤, 赶走, 闷热, 舒爽, 通透, 不...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2024-07-31</td>
      <td>ABC卫生巾真的是女生的小贴心❤️，用起来超级舒服，不闷不热，吸收力超强！量大也不怕，完全不...</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>81</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 吸收力超强、量大、不侧漏\...</td>
      <td>吸收力超强、量大、不侧漏</td>
      <td>超级舒服、不闷不热、稳稳的、幸福感爆棚</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-07-31</td>
      <td>[吸收, 力, 超强, 量, 大, 不, 侧, 漏, 超级, 舒服, 不, 闷, 不, 热,...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2024-06-28</td>
      <td>夏天用ABC的可以清凉一点吧。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>15</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 清凉\n   - 使用体验...</td>
      <td>清凉</td>
      <td>无</td>
      <td>无</td>
      <td>无</td>
      <td>3</td>
      <td>2024-06-28</td>
      <td>[清凉, 无, 无, 无]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2024-05-27</td>
      <td>好评好评，物流快服务好，天猫超市买东西就是好用。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>24</td>
      <td>\n### 输入:\n**产品类别**: 卫生巾\n**评论**: “好评好评，物流快服务好...</td>
      <td>无</td>
      <td>天猫超市买东西好用</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-05-27</td>
      <td>[无, 天猫超市, 买东西, 好, 用, 无, 无]</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>2024-06-07</td>
      <td>最爱用的卫生巾 好用</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 好用\n   - 使用体验...</td>
      <td>好用</td>
      <td>[无相关关键词]</td>
      <td>[无相关关键词]</td>
      <td>[无相关关键词]</td>
      <td>5</td>
      <td>2024-06-07</td>
      <td>[好, 用, [, 无, 相关, 关键词, ], [, 无, 相关, 关键词, ], [, ...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2024-08-03</td>
      <td>一直用的一款一直回购</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>10</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>一直用、回购</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-08-03</td>
      <td>[无, 一直, 用, 回购, 无, 无]</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>2024-08-02</td>
      <td>送货上门，购物方便，省去了去超市选购的时间。</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>22</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>购物方便、省时</td>
      <td>无</td>
      <td>无</td>
      <td>4</td>
      <td>2024-08-02</td>
      <td>[无, 购物, 方便, 省时, 无, 无]</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>2024-07-30</td>
      <td>东西质量非常好，与卖家描述的完全一致，非常满意</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 质量好、描述一致\n   ...</td>
      <td>质量好、描述一致</td>
      <td>无</td>
      <td>无</td>
      <td>无</td>
      <td>5</td>
      <td>2024-07-30</td>
      <td>[质量好, 描述, 一致, 无, 无, 无]</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>2024-07-29</td>
      <td>半日达很方便 每次都能很及时收到 价格也很便宜</td>
      <td>淘宝</td>
      <td>ABC卫生巾</td>
      <td>ABC</td>
      <td>卫生巾</td>
      <td>23</td>
      <td>\n1. **关键词提取与归类**:\n   - 产品质量相关: 无\n   - 使用体验相...</td>
      <td>无</td>
      <td>半日达方便 及时</td>
      <td>无</td>
      <td>便宜</td>
      <td>4</td>
      <td>2024-07-29</td>
      <td>[无, 半日, 达, 方便,  , 及时, 无, 便宜]</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.to_excel("process.xlsx")
```


```python

```
